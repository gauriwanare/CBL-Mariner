
#ifndef TEST_COMMON_H
#define TEST_COMMON_H

#include <check.h>

Suite *make_suite_test_string(void);
Suite *make_suite_test_os_calls(void);

#endif /* TEST_COMMON_H */
