#ifndef TEST_XRDP_H
#define TEST_XRDP_H

#include <check.h>

Suite *make_suite_test_bitmap_load(void);

#endif /* TEST_XRDP_H */
